import React, { useEffect, useRef, useState } from "react";
import styles from "./ScrollingInfoBar.module.css";

const announcements = [
  "公告1：欢迎使用车险代理查询系统。",
  "公告2：系统今晚10点维护，请提前保存数据。这是超长内容测试，这是超长内容测试，这是超长内容测试，这是超长内容测试，这是超长内容测试。",
  "公告3：请及时补全客户信息以免理赔受阻，谢谢合作。",
  "这是超长内容测试，这是超长内容测试，这是超长内容测试，这是超长内容测试，这是超长内容测试。",
];

const SCROLL_DURATION = 4000;
const PAUSE_DURATION = 1000;
const TOTAL_DURATION = (SCROLL_DURATION + PAUSE_DURATION) * 2;

const ScrollingInfoBar: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [phase, setPhase] = useState<"start" | "scroll1" | "pause1" | "scroll2" | "pause2">("start");
  const scrollRef = useRef<HTMLDivElement>(null);
  const [distance, setDistance] = useState(0);
  const [needScroll, setNeedScroll] = useState(false);

  // 检查内容是否超出
  useEffect(() => {
    setTimeout(() => {
      const el = scrollRef.current;
      if (el) {
        const d = el.scrollWidth - el.clientWidth;
        setNeedScroll(d > 2);
        setDistance(d > 0 ? d : 0);
      }
    }, 10);
  }, [currentIndex]);

  // 控制每个阶段的动画
  useEffect(() => {
    let t1: number, t2: number, t3: number, t4: number;
    if (!needScroll) {
      // 10秒切到下一条
      t1 = window.setTimeout(() => setCurrentIndex((i) => (i + 1) % announcements.length), TOTAL_DURATION);
      return () => clearTimeout(t1);
    }
    setPhase("start");
    // 第一次滚动
    t1 = window.setTimeout(() => setPhase("scroll1"), 0); // 立即滚动
    t2 = window.setTimeout(() => setPhase("pause1"), SCROLL_DURATION); // 滚完后暂停
    t3 = window.setTimeout(() => setPhase("scroll2"), SCROLL_DURATION + PAUSE_DURATION); // 第二次滚
    t4 = window.setTimeout(() => setPhase("pause2"), SCROLL_DURATION * 2 + PAUSE_DURATION); // 滚完暂停
    // 切换下一条
    const t5 = window.setTimeout(() => setCurrentIndex((i) => (i + 1) % announcements.length), TOTAL_DURATION);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, [currentIndex, needScroll]);

  // 计算当前的transform
  let style: React.CSSProperties = {};
  if (!needScroll) {
    style.transform = "translateX(0)";
    style.transition = "none";
  } else if (phase === "start" || phase === "pause1" || phase === "pause2") {
    style.transform = "translateX(0)";
    style.transition = "none";
  } else if (phase === "scroll1" || phase === "scroll2") {
    style.transform = `translateX(-${distance}px)`;
    style.transition = `transform ${SCROLL_DURATION}ms linear`;
  }

  return (
    <div className={styles.scrollingBarOuter}>
      <div className={styles.scrollingBarInner} style={style} ref={scrollRef}>
        <span>{announcements[currentIndex]}</span>
      </div>
    </div>
  );
};

export default ScrollingInfoBar;
